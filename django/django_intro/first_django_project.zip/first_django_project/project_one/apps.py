from django.apps import AppConfig


class ProjectOneConfig(AppConfig):
    name = 'project_one'
