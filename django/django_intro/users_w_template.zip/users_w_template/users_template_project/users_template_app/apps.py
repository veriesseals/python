from django.apps import AppConfig


class UsersTemplateAppConfig(AppConfig):
    name = 'users_template_app'
