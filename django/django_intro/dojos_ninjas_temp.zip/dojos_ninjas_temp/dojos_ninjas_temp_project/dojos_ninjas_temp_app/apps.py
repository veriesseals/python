from django.apps import AppConfig


class DojosNinjasTempAppConfig(AppConfig):
    name = 'dojos_ninjas_temp_app'
