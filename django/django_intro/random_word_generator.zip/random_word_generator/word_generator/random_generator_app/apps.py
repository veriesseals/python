from django.apps import AppConfig


class RandomGeneratorAppConfig(AppConfig):
    name = 'random_generator_app'
